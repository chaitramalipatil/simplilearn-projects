package com.sanmatibanne.ExpenseTracker.dto;

public record CategoryDto(Long id,
                          String name) {

}
