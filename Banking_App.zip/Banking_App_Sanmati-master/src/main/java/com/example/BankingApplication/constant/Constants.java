package com.example.BankingApplication.constant;

public class Constants {

    public static final String  TRANSACTION_TYPE_DEPOSIT= "Deposit";
    public static final String  TRANSACTION_TYPE_WITHDRAW= "Withdraw";

    public static final String  TRANSACTION_TYPE_TRANSFER= "Transfer";
}
